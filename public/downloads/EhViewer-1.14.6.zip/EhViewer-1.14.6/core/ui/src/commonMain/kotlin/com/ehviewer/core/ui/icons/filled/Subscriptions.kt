package com.ehviewer.core.ui.icons.filled

import androidx.compose.foundation.Image
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.ehviewer.core.ui.icons.EhIcons
import com.ehviewer.core.util.unsafeLazy

val EhIcons.Filled.Subscriptions by unsafeLazy {
    materialIcon(name = "Subscriptions") {
        materialPath {
            moveTo(20.0F, 8.0F)
            horizontalLineTo(4.0F)
            verticalLineTo(6.0F)
            horizontalLineToRelative(16.0F)
            verticalLineTo(8.0F)
            moveTo(18.0F, 2.0F)
            horizontalLineTo(6.0F)
            verticalLineToRelative(2.0F)
            horizontalLineToRelative(12.0F)
            verticalLineTo(2.0F)
            moveTo(20.0F, 10.0F)
            horizontalLineTo(4.0F)
            curveToRelative(-1.1F, 0.0F, -2.0F, 0.9F, -2.0F, 2.0F)
            verticalLineToRelative(8.0F)
            curveToRelative(0.0F, 1.1F, 0.9F, 2.0F, 2.0F, 2.0F)
            horizontalLineToRelative(16.0F)
            curveToRelative(1.1F, 0.0F, 2.0F, -0.9F, 2.0F, -2.0F)
            verticalLineToRelative(-8.0F)
            curveTo(22.0F, 10.9F, 21.1F, 10.0F, 20.0F, 10.0F)
            close()
            moveTo(11.0F, 14.0F)
            horizontalLineTo(7.0F)
            verticalLineToRelative(1.0F)
            horizontalLineToRelative(4.0F)
            verticalLineToRelative(2.0F)
            horizontalLineTo(7.0F)
            verticalLineToRelative(1.0F)
            horizontalLineToRelative(4.0F)
            verticalLineToRelative(2.0F)
            horizontalLineTo(5.0F)
            verticalLineToRelative(-8.0F)
            horizontalLineToRelative(6.0F)
            verticalLineTo(14.0F)
            close()
            moveTo(19.0F, 20.0F)
            horizontalLineToRelative(-2.0F)
            verticalLineToRelative(-3.0F)
            horizontalLineToRelative(-2.0F)
            verticalLineToRelative(3.0F)
            horizontalLineToRelative(-2.0F)
            verticalLineToRelative(-8.0F)
            horizontalLineToRelative(2.0F)
            verticalLineToRelative(3.0F)
            horizontalLineToRelative(2.0F)
            verticalLineToRelative(-3.0F)
            horizontalLineToRelative(2.0F)
            verticalLineTo(20.0F)
            close()
        }
    }
}

@Preview
@Composable
@Suppress("UnusedPrivateMember")
private fun IconSubscriptionsPreview() {
    Image(imageVector = EhIcons.Default.Subscriptions, contentDescription = null)
}
