package com.ehviewer.core.ui.icons.filled

import androidx.compose.foundation.Image
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.ehviewer.core.ui.icons.EhIcons
import com.ehviewer.core.util.unsafeLazy

val EhIcons.Filled.Crop by unsafeLazy {
    materialIcon(name = "Crop") {
        materialPath {
            moveTo(17.0F, 15.0F)
            horizontalLineToRelative(2.0F)
            verticalLineTo(7.0F)
            curveToRelative(0.0F, -1.1F, -0.9F, -2.0F, -2.0F, -2.0F)
            horizontalLineTo(9.0F)
            verticalLineToRelative(2.0F)
            horizontalLineToRelative(8.0F)
            verticalLineToRelative(8.0F)
            close()
            moveTo(7.0F, 17.0F)
            verticalLineTo(1.0F)
            horizontalLineTo(5.0F)
            verticalLineToRelative(4.0F)
            horizontalLineTo(1.0F)
            verticalLineToRelative(2.0F)
            horizontalLineToRelative(4.0F)
            verticalLineToRelative(10.0F)
            curveToRelative(0.0F, 1.1F, 0.9F, 2.0F, 2.0F, 2.0F)
            horizontalLineToRelative(10.0F)
            verticalLineToRelative(4.0F)
            horizontalLineToRelative(2.0F)
            verticalLineToRelative(-4.0F)
            horizontalLineToRelative(4.0F)
            verticalLineToRelative(-2.0F)
            horizontalLineTo(7.0F)
            close()
        }
    }
}

@Preview
@Composable
@Suppress("UnusedPrivateMember")
private fun IconCropPreview() {
    Image(imageVector = EhIcons.Default.Crop, contentDescription = null)
}
