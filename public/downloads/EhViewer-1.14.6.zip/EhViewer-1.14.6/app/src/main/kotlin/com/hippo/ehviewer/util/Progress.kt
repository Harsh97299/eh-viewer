package com.hippo.ehviewer.util

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.CircularWavyProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import com.ehviewer.core.i18n.R
import com.hippo.ehviewer.ui.tools.DialogState
import kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED
import kotlin.coroutines.intrinsics.startCoroutineUninterceptedOrReturn
import kotlin.coroutines.intrinsics.suspendCoroutineUninterceptedOrReturn

@Composable
fun ProgressDialog() {
    BasicAlertDialog(
        onDismissRequest = { },
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
    ) {
        Surface(
            modifier = Modifier.width(280.dp),
            shape = AlertDialogDefaults.shape,
            color = AlertDialogDefaults.containerColor,
            tonalElevation = AlertDialogDefaults.TonalElevation,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(18.dp),
            ) {
                CircularWavyProgressIndicator()
                Spacer(modifier = Modifier.size(18.dp))
                Text(text = stringResource(id = R.string.please_wait))
            }
        }
    }
}

context(state: DialogState)
suspend fun <R> bgWork(work: suspend () -> R) = state.mutex.mutate {
    try {
        suspendCoroutineUninterceptedOrReturn { cont ->
            work.startCoroutineUninterceptedOrReturn(cont).also { r ->
                if (r == COROUTINE_SUSPENDED) state.value = { ProgressDialog() }
            }
        }
    } finally {
        state.dismiss()
    }
}
