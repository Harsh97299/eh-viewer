package com.hippo.ehviewer.ui.login

import arrow.core.Either.Companion.catch
import com.ehviewer.core.network.EhCookieStore
import com.ehviewer.core.util.logcat
import com.hippo.ehviewer.Settings
import com.hippo.ehviewer.client.EhEngine
import com.hippo.ehviewer.client.EhUrl
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

suspend fun CoroutineScope.refreshAccountInfo() = catch {
    with(EhEngine.getProfile()) {
        Settings.displayName.value = displayName
        Settings.avatar.value = avatar
    }
}.onLeft {
    logcat(it)
}

@OptIn(DelicateCoroutinesApi::class)
fun postLogin() = GlobalScope.async(Dispatchers.IO) {
    launch { refreshAccountInfo() }

    // For the `star` cookie
    catch {
        EhEngine.getNews(false)
    }.onLeft {
        logcat(it)
    }

    // Get cookies for image limits
    launch {
        catch {
            EhEngine.getUConfig(EhUrl.SITE_E)
            EhCookieStore.flush()
        }.onLeft {
            logcat(it)
        }
    }

    // Sad panda check
    catch {
        EhEngine.getUConfig(EhUrl.SITE_EX)
        EhCookieStore.flush()
        Settings.gallerySite.value = EhUrl.SITE_EX
    }.onLeft {
        Settings.gallerySite.value = EhUrl.SITE_E
    }

    Settings.hasSignedIn.value = true
    Settings.needSignIn.value = false
}
